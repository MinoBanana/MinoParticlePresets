
package net.particleeffects.client.renderer;

import net.particleeffects.entity.TestbEntity;
import net.particleeffects.client.model.Modelnuke;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;

import com.mojang.blaze3d.vertex.PoseStack;

public class TestbRenderer extends MobRenderer<TestbEntity, Modelnuke<TestbEntity>> {
	public TestbRenderer(EntityRendererProvider.Context context) {
		super(context, new Modelnuke(context.bakeLayer(Modelnuke.LAYER_LOCATION)), 0.5f);
	}

	@Override
	protected void scale(TestbEntity entity, PoseStack poseStack, float f) {
		poseStack.scale(0.1f, 0.1f, 0.1f);
	}

	@Override
	public ResourceLocation getTextureLocation(TestbEntity entity) {
		return new ResourceLocation("particlepresets:textures/entities/mushroom.png");
	}
}
