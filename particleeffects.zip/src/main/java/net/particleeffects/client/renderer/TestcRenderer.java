
package net.particleeffects.client.renderer;

import net.particleeffects.entity.TestcEntity;
import net.particleeffects.client.model.Modelnuke_top;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;

public class TestcRenderer extends MobRenderer<TestcEntity, Modelnuke_top<TestcEntity>> {
	public TestcRenderer(EntityRendererProvider.Context context) {
		super(context, new Modelnuke_top(context.bakeLayer(Modelnuke_top.LAYER_LOCATION)), 0.5f);
	}

	@Override
	public ResourceLocation getTextureLocation(TestcEntity entity) {
		return new ResourceLocation("particlepresets:textures/entities/mushroom.png");
	}
}
