
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.particleeffects.init;

import net.particleeffects.client.renderer.TestcRenderer;
import net.particleeffects.client.renderer.TestbRenderer;
import net.particleeffects.client.renderer.SummoningcircleRenderer;
import net.particleeffects.client.renderer.RitualcirclesmallRenderer;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.api.distmarker.Dist;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ParticlepresetsModEntityRenderers {
	@SubscribeEvent
	public static void registerEntityRenderers(EntityRenderersEvent.RegisterRenderers event) {
		event.registerEntityRenderer(ParticlepresetsModEntities.SUMMONINGCIRCLE.get(), SummoningcircleRenderer::new);
		event.registerEntityRenderer(ParticlepresetsModEntities.RITUALCIRCLESMALL.get(), RitualcirclesmallRenderer::new);
		event.registerEntityRenderer(ParticlepresetsModEntities.TESTB.get(), TestbRenderer::new);
		event.registerEntityRenderer(ParticlepresetsModEntities.TESTC.get(), TestcRenderer::new);
	}
}
