
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.particleeffects.init;

import net.particleeffects.block.NukeRingBlock;
import net.particleeffects.block.IceShardBlock;
import net.particleeffects.ParticlepresetsMod;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;

public class ParticlepresetsModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, ParticlepresetsMod.MODID);
	public static final RegistryObject<Block> ICE_SHARD = REGISTRY.register("ice_shard", () -> new IceShardBlock());
	public static final RegistryObject<Block> NUKE_RING = REGISTRY.register("nuke_ring", () -> new NukeRingBlock());
	// Start of user code block custom blocks
	// End of user code block custom blocks
}
