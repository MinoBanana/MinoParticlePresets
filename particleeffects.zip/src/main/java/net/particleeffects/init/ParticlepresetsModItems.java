
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.particleeffects.init;

import net.particleeffects.item.ElectricSwordItem;
import net.particleeffects.ParticlepresetsMod;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.common.ForgeSpawnEggItem;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

public class ParticlepresetsModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, ParticlepresetsMod.MODID);
	public static final RegistryObject<Item> SUMMONINGCIRCLE_SPAWN_EGG = REGISTRY.register("summoningcircle_spawn_egg", () -> new ForgeSpawnEggItem(ParticlepresetsModEntities.SUMMONINGCIRCLE, -1, -1, new Item.Properties()));
	public static final RegistryObject<Item> RITUALCIRCLESMALL_SPAWN_EGG = REGISTRY.register("ritualcirclesmall_spawn_egg", () -> new ForgeSpawnEggItem(ParticlepresetsModEntities.RITUALCIRCLESMALL, -1, -1, new Item.Properties()));
	public static final RegistryObject<Item> ELECTRIC_SWORD = REGISTRY.register("electric_sword", () -> new ElectricSwordItem());
	public static final RegistryObject<Item> ICE_SHARD = block(ParticlepresetsModBlocks.ICE_SHARD);
	public static final RegistryObject<Item> TESTB_SPAWN_EGG = REGISTRY.register("testb_spawn_egg", () -> new ForgeSpawnEggItem(ParticlepresetsModEntities.TESTB, -1, -1, new Item.Properties()));
	public static final RegistryObject<Item> TESTC_SPAWN_EGG = REGISTRY.register("testc_spawn_egg", () -> new ForgeSpawnEggItem(ParticlepresetsModEntities.TESTC, -1, -1, new Item.Properties()));
	public static final RegistryObject<Item> NUKE_RING = block(ParticlepresetsModBlocks.NUKE_RING);

	// Start of user code block custom items
	// End of user code block custom items
	private static RegistryObject<Item> block(RegistryObject<Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties()));
	}
}
