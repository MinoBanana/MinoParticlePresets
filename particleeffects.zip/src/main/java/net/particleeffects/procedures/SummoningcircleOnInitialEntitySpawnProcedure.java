package net.particleeffects.procedures;

public class SummoningcircleOnInitialEntitySpawnProcedure {
	public static void execute() {
	}
}
