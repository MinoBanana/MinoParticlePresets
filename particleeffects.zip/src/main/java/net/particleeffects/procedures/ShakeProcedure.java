package net.particleeffects.procedures;

import net.particleeffects.network.ParticlepresetsModVariables;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;

public class ShakeProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		{
			double _setval = (entity.getCapability(ParticlepresetsModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new ParticlepresetsModVariables.PlayerVariables())).quake + 1;
			entity.getCapability(ParticlepresetsModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
				capability.quake = _setval;
				capability.syncPlayerVariables(entity);
			});
		}
		if ((entity.getCapability(ParticlepresetsModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new ParticlepresetsModVariables.PlayerVariables())).quake == 0) {
			{
				Entity _ent = entity;
				_ent.setYRot((float) (entity.getYRot() + 1));
				_ent.setXRot((float) (entity.getXRot() + 1));
				_ent.setYBodyRot(_ent.getYRot());
				_ent.setYHeadRot(_ent.getYRot());
				_ent.yRotO = _ent.getYRot();
				_ent.xRotO = _ent.getXRot();
				if (_ent instanceof LivingEntity _entity) {
					_entity.yBodyRotO = _entity.getYRot();
					_entity.yHeadRotO = _entity.getYRot();
				}
			}
		} else if ((entity.getCapability(ParticlepresetsModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new ParticlepresetsModVariables.PlayerVariables())).quake == 1) {
			{
				Entity _ent = entity;
				_ent.setYRot((float) (entity.getYRot() + -2));
				_ent.setXRot((float) (entity.getXRot() + -2));
				_ent.setYBodyRot(_ent.getYRot());
				_ent.setYHeadRot(_ent.getYRot());
				_ent.yRotO = _ent.getYRot();
				_ent.xRotO = _ent.getXRot();
				if (_ent instanceof LivingEntity _entity) {
					_entity.yBodyRotO = _entity.getYRot();
					_entity.yHeadRotO = _entity.getYRot();
				}
			}
		} else if ((entity.getCapability(ParticlepresetsModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new ParticlepresetsModVariables.PlayerVariables())).quake == 2) {
			{
				Entity _ent = entity;
				_ent.setYRot((float) (entity.getYRot() + 1));
				_ent.setXRot((float) (entity.getXRot() + 1));
				_ent.setYBodyRot(_ent.getYRot());
				_ent.setYHeadRot(_ent.getYRot());
				_ent.yRotO = _ent.getYRot();
				_ent.xRotO = _ent.getXRot();
				if (_ent instanceof LivingEntity _entity) {
					_entity.yBodyRotO = _entity.getYRot();
					_entity.yHeadRotO = _entity.getYRot();
				}
			}
		} else if ((entity.getCapability(ParticlepresetsModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new ParticlepresetsModVariables.PlayerVariables())).quake == 3) {
			{
				Entity _ent = entity;
				_ent.setYRot((float) (entity.getYRot() + 1));
				_ent.setXRot((float) (entity.getXRot() + -1));
				_ent.setYBodyRot(_ent.getYRot());
				_ent.setYHeadRot(_ent.getYRot());
				_ent.yRotO = _ent.getYRot();
				_ent.xRotO = _ent.getXRot();
				if (_ent instanceof LivingEntity _entity) {
					_entity.yBodyRotO = _entity.getYRot();
					_entity.yHeadRotO = _entity.getYRot();
				}
			}
		} else if ((entity.getCapability(ParticlepresetsModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new ParticlepresetsModVariables.PlayerVariables())).quake == 4) {
			{
				Entity _ent = entity;
				_ent.setYRot((float) (entity.getYRot() + 0));
				_ent.setXRot((float) (entity.getXRot() + 1));
				_ent.setYBodyRot(_ent.getYRot());
				_ent.setYHeadRot(_ent.getYRot());
				_ent.yRotO = _ent.getYRot();
				_ent.xRotO = _ent.getXRot();
				if (_ent instanceof LivingEntity _entity) {
					_entity.yBodyRotO = _entity.getYRot();
					_entity.yHeadRotO = _entity.getYRot();
				}
			}
		}
		if ((entity.getCapability(ParticlepresetsModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new ParticlepresetsModVariables.PlayerVariables())).quake > 4) {
			{
				double _setval = 0;
				entity.getCapability(ParticlepresetsModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
					capability.quake = _setval;
					capability.syncPlayerVariables(entity);
				});
			}
		}
	}
}
