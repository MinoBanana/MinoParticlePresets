package net.particleeffects.procedures;

import net.particleeffects.ParticlepresetsMod;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.Vec2;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.network.chat.Component;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.CommandSource;

public class NukeTestProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z) {
		ParticlepresetsMod.queueServerWork(1, () -> {
			if (world instanceof ServerLevel _level)
				_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
						"execute align xyz run summon block_display ~ ~15 ~ {Tags:[\"explode\"], shadow_radius:0f, shadow_strength:0f, width:3f, height:1f, brightness:{sky:15, block:0}, block_state:{Name:\"particlepresets:nuke_ring\"}, transformation:{scale:[0f,0f,0f], right_rotation:[0f,0f,0f,1f], left_rotation:[0f,0f,0f,1f]}}");
		});
		ParticlepresetsMod.queueServerWork(1, () -> {
			if (world instanceof ServerLevel _level)
				_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
						"data merge entity @e[type=block_display,sort=nearest,limit=1] {transformation:{left_rotation:[0f,1f,0f,1f], right_rotation:[0f,1f,0f,1f], translation:[-5f,0f,-5f], scale:[10f,1f,10f]}, start_interpolation:0, interpolation_duration:100}");
			ParticlepresetsMod.queueServerWork(110, () -> {
			});
		});
	}
}
